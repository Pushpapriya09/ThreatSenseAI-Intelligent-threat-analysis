from fastapi import APIRouter
from backend.services.router_service import route_request

router = APIRouter()

@router.post("/analyze")
async def analyze(request: dict):
    result = route_request(request.get("type", "message_detection"), request.get("data", ""))
    return result
