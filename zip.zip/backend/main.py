"""
SafeClick AI — Python Backend (FastAPI)

This is the main entry point for the Python backend.
It creates the FastAPI app, adds CORS middleware (so the
React frontend can call it), and registers all API routes.

To run:
    cd SafeClick-AI-main
    uvicorn backend.main:app --reload --port 8000
"""

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from backend.routers import analyze, chat, daily_briefing

# Create the FastAPI app
app = FastAPI(
    title="SafeClick AI Backend",
    description="Python backend for cybersecurity analysis powered by Gemini AI",
    version="1.0.0",
)

# Allow the React frontend (localhost:9002) to call our API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API routes — all prefixed with /api
app.include_router(analyze.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(daily_briefing.router, prefix="/api")

# Serve the frontend as static files
frontend_dir = os.path.join(os.path.dirname(__file__), "../frontend")
if os.path.exists(frontend_dir):
    app.mount("/assets", StaticFiles(directory=os.path.join(frontend_dir, "assets")), name="assets")
    app.mount("/css", StaticFiles(directory=os.path.join(frontend_dir, "css")), name="css")
    app.mount("/js", StaticFiles(directory=os.path.join(frontend_dir, "js")), name="js")
    
    @app.get("/")
    async def serve_root():
        return FileResponse(os.path.join(frontend_dir, "index.html"))

    @app.get("/index.html")
    async def serve_index_html():
        return FileResponse(os.path.join(frontend_dir, "index.html"))
        
    @app.get("/dashboard")
    async def serve_dashboard():
        return FileResponse(os.path.join(frontend_dir, "dashboard.html"))

    @app.get("/dashboard.html")
    async def serve_dashboard_html():
        return FileResponse(os.path.join(frontend_dir, "dashboard.html"))
else:
    @app.get("/")
    async def root():
        """Health check endpoint."""
        return {"status": "ok", "service": "SafeClick AI Python Backend"}
