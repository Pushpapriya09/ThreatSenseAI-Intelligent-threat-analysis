"""
============================================================
SERVICE: QR Code Security Analyzer
OWNER:   Antigravity
============================================================

Analyzes QR code images for security risks (phishing, scams)
using Gemini AI's multimodal capabilities.
============================================================
"""

import json
from backend.services.gemini_service import get_gemini_client, get_model_id
from google.genai import types
import base64
import io

SYSTEM_PROMPT = (
    "You are a cybersecurity expert. "
    "The user has uploaded an image of a QR code. "
    "1. Decode the QR code to find the URL or text it contains. "
    "2. Analyze that content for security risks (phishing, malicious downloads, scams). "
    "Return ONLY valid raw JSON (no markdown, no explanation) in this format:\n"
    '{ "classification": "SAFE | SUSPICIOUS | DANGEROUS", '
    '"risk_score": number, "reasons": string[], "recommendation": "string" }'
)

def analyze_qr(base64_image: str) -> dict:
    """
    Decodes and analyzes a QR code from a base64-encoded image.

    Args:
        base64_image: The QR code image as a base64 string.

    Returns:
        Dictionary with classification, risk_score, reasons, recommendation.
    """
    client = get_gemini_client()
    
    # Remove metadata prefix if present (e.g., "data:image/png;base64,")
    if "," in base64_image:
        base64_image = base64_image.split(",")[1]

    try:
        response = client.models.generate_content(
            model=get_model_id(),
            contents=[
                types.Part.from_bytes(
                    data=base64.b64decode(base64_image),
                    mime_type="image/png"  # Default to png, Gemini is usually smart enough
                ),
                "Analyze this QR code image for security risks."
            ],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                system_instruction=SYSTEM_PROMPT,
            ),
        )

        # Parse the JSON response from Gemini
        response_text = response.text
        cleaned = response_text.replace("```json", "").replace("```", "").strip()
        result = json.loads(cleaned)
        return result

    except Exception as e:
        print(f"Error in analyze_qr: {e}")
        return {
            "classification": "SUSPICIOUS",
            "risk_score": 50,
            "reasons": [f"Analysis failed: {str(e)}"],
            "recommendation": "Exercise caution. The QR code could not be fully analyzed."
        }
