"""
Shared Gemini AI client.
Provides a single reusable client instance for all services.
"""

from google import genai
from backend.config import GEMINI_API_KEY, GEMINI_MODEL


def get_gemini_client() -> genai.Client:
    """Creates and returns a Gemini AI client."""
    return genai.Client(api_key=GEMINI_API_KEY)


def get_model_id() -> str:
    """Returns the configured Gemini model ID."""
    return GEMINI_MODEL


def analyze_with_gemini(text: str) -> str:
    """Analyzes text for security risks using Gemini."""
    client = get_gemini_client()
    try:
        response = client.models.generate_content(
            model=get_model_id(),
            contents=f"Analyze this text for security risks and explain why it might be dangerous or safe. Text: {text}"
        )
        return response.text
    except Exception as e:
        return f"Error during Gemini analysis: {str(e)}"
