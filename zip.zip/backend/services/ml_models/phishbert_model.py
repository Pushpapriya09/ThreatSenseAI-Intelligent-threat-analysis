from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

MODEL_NAME = "ealvaradob/bert-finetuned-phishing"

_tokenizer = None
_model = None

def get_model():
    global _tokenizer, _model
    if _model is None:
        try:
            print(f"Loading model {MODEL_NAME}...")
            _tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
            _model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME)
            print("Model loaded successfully.")
        except Exception as e:
            print(f"Warning: Could not load {MODEL_NAME}: {e}")
    return _tokenizer, _model

def predict_phishing(text: str):
    tokenizer, model = get_model()
    if not tokenizer or not model:
        return {"label": "SAFE", "confidence": 0.0}
        
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    
    with torch.no_grad():
        outputs = model(**inputs)
    
    probs = torch.softmax(outputs.logits, dim=1)
    score = probs[0][1].item()  # phishing probability

    return {
        "label": "PHISHING" if score > 0.5 else "SAFE",
        "confidence": score
    }
