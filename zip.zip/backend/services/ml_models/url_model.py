import joblib
import os

# Create models directory if it doesn't exist
models_dir = os.path.join(os.path.dirname(__file__), "../../../models")
os.makedirs(models_dir, exist_ok=True)
model_path = os.path.join(models_dir, "url_model.pkl")

class DummyModel:
    def predict_proba(self, features):
        return [[0.8, 0.2]] # Safe by default

try:
    model = joblib.load(model_path)
except FileNotFoundError:
    print("Warning: url_model.pkl not found. Please train and save the model. Using dummy model for now.")
    model = DummyModel()

def extract_features(url):
    return [
        len(url),
        url.count('.'),
        int("https" in url),
        int("@" in url),
    ]

def predict_url(url: str):
    features = extract_features(url)
    score = model.predict_proba([features])[0][1]

    return {
        "label": "MALICIOUS" if score > 0.5 else "SAFE",
        "confidence": score
    }
