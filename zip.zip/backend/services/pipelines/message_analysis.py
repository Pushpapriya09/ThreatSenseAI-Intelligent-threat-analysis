from ..gpt_service import analyze_message

def run_message_analysis(text):
    return analyze_message(text)
