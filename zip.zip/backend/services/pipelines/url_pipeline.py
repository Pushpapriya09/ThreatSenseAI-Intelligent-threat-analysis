from ..ml_models.url_model import predict_url
from ..gemini_service import analyze_with_gemini

def run_url_analysis(url):
    ml_result = predict_url(url)

    explanation = analyze_with_gemini(url)

    return {
        "classification": ml_result["label"],
        "confidence": ml_result["confidence"],
        "explanation": explanation
    }
