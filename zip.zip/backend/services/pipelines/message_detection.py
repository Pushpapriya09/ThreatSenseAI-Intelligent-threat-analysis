from ..ml_models.phishbert_model import predict_phishing
from ..gemini_service import analyze_with_gemini

def run_message_detection(text):
    ml_result = predict_phishing(text)

    if ml_result["confidence"] > 0.6:
        explanation = analyze_with_gemini(text)
    else:
        explanation = "Low risk message."

    return {
        "classification": ml_result["label"],
        "confidence": ml_result["confidence"],
        "explanation": explanation
    }
