from openai import OpenAI
import os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", "YOUR_KEY"))

def analyze_message(message):
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a cybersecurity expert."},
                {"role": "user", "content": message}
            ]
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Error analyzing message: {str(e)}"
