from .pipelines.message_detection import run_message_detection
from .pipelines.message_analysis import run_message_analysis
from .pipelines.url_pipeline import run_url_analysis
from .qr_analyzer import analyze_qr

def route_request(input_type, data):
    
    if input_type == "message_detection":
        return run_message_detection(data)
    
    elif input_type == "message_analysis":
        # Since analyze_message returns a string but the endpoint expects a dict with classification, risk_score etc
        # we will wrap it
        res = run_message_analysis(data)
        return {
            "classification": "ANALYZED",
            "confidence": 1.0,
            "explanation": res
        }
        
    elif input_type == "url":
        return run_url_analysis(data)
    
    elif input_type == "qr_code":
        return analyze_qr(data)
    
    else:
        return {"error": "Invalid type"}
